
public class FichaVer2 {

	public String forma;
	public int f;
	public int c;
	
	public FichaVer2(String f) {
		
		forma = f;
	}

	public FichaVer2() {
		// sobrecarga
	}
	
}
