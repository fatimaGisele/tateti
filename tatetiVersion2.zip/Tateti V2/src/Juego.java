
public class Juego {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Tablero t1=new Tablero();
		t1.mostrarMatriz();
		t1.m[1][2]=new Ficha("X");
		t1.m[2][0] = new Ficha("O");
		t1.mostrarMatriz();*/
		
		TatetiVer2 tate = new TatetiVer2();
		tate.jugar();
	}

}
